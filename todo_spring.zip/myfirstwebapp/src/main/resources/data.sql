insert into todo (ID, USERNAME, DESCRIPTION, Date, DONE)
values(10001,'krishna', 'Get all done', CURRENT_DATE(), false);

insert into todo (ID, USERNAME, DESCRIPTION, Date, DONE)
values(10002,'krishna', 'Get two done', CURRENT_DATE(), false);

insert into todo (ID, USERNAME, DESCRIPTION, Date, DONE)
values(10003,'krishna', 'Gettheerafd', CURRENT_DATE(), false);

insert into todo (ID, USERNAME, DESCRIPTION, Date, DONE)
values(1004,'krishna', 'Get 4 done', CURRENT_DATE(), false);